package com.example.flywaydb;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;

	public List<Employee> getAllHospitals() {
		return employeeRepository.findAll();
	}

	public Optional<Employee> getHospital(int id) {

		return employeeRepository.findById(id);
	}

	public void addHospital(Employee hospital) {
		employeeRepository.save(hospital);
	}

	public void updateHospital(Employee hospital) {

		employeeRepository.save(hospital);

	}

	public void deleteHospital(int id) {

		employeeRepository.deleteById(id);

	}

}
