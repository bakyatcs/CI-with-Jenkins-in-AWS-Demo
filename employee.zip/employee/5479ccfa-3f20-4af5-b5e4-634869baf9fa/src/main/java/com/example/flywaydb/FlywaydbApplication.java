package com.example.flywaydb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlywaydbApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlywaydbApplication.class, args);
	}
}
